package bonch.dev.school.fragments

import android.support.v4.app.Fragment

class FirstFragment : Fragment() {
}